/**
 * Created by hong on 2014/6/4.
 */

function PhaseUpload() {
    // Public member ----------------------------------------------------------
    this.Initialize = Initialize;
    function Initialize() {
        $('button.upload').bind('click', UploadData);
    }
    function UploadData() {
        var output_data = [];
        function Structure(inventory_no, inventory_name, inventory_cost, inventory_type, inventory_weight) {
            this.no = inventory_no;
            this.name = inventory_name;
            this.cost = inventory_cost;
            this.type = inventory_type;
            this.weight = inventory_weight;
        }
//        var column_name = ["no", "name", "cost", 'type', 'weight'];
        var domain = $("tbody.inventory_add");
        var domain_set = domain.find("tr");
        var inventory_max = parseInt(domain.attr("id"));

        var inventory_no, inventory_name, inventory_cost, inventory_type, inventory_weight;
        for (var inventory_index = 0; inventory_index < inventory_max; ++inventory_index) {
            var domain_current = $(domain_set[inventory_index]);
            if(domain_current[0].cells[0].childNodes[0].value !="" && domain_current[0].cells[1].childNodes[0].value !="" && domain_current[0].cells[2].childNodes[0].value !=null && domain_current[0].cells[3].childNodes[0].value !=null){
                inventory_no = domain_current[0].cells[0].childNodes[0].value;
                inventory_name = domain_current[0].cells[1].childNodes[0].value;
                inventory_cost = parseInt(domain_current[0].cells[2].childNodes[0].value);
                inventory_type = domain_current[0].cells[3].childNodes[0].value;
                inventory_weight = parseInt(domain_current[0].cells[4].childNodes[0].value);
                output_data[inventory_index] = new Structure(inventory_no, inventory_name, inventory_cost, inventory_type, inventory_weight);
            }else{
                alert('請勿有空白欄位');
                this.parents().preventDefault();
            }
        }
        var post_data = new Object();
        post_data.inventory = output_data;
        console.log(JSON.stringify(post_data));

        $.post( "http://192.168.1.2:8888/inventory?type=update", post_data).done(function( data ) {
            if(data.successful){
                var info =$('div.Info2').empty();
                var str_alert ="";
                str_alert +='<div class="alert alert-success" role="alert"><strong>新增 '+post_data.inventory.length+' 筆資料成功</strong></div>';
                str_alert +='<div class="alert alert-warning" role="alert"><strong>提醒! 成本將自動依比例更新</strong></div>';
                info.append(str_alert);

                var list_reload = new PhaseList();
                list_reload.Reload();
            }
            else{
                var err_info =$('div.Info2').empty();
                var str_alert_err ="";
                str_alert_err +='<div class="alert alert-danger" role="alert"><strong>新增失敗</strong></div>';
                err_info.append(str_alert_err);
            }
        });
        domain.empty();
    }
}
