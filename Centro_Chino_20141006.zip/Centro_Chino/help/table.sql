

CREATE TABLE inventory (
 ID int IDENTITY(1,1) PRIMARY KEY,
 no nvarchar(15),
 name nvarchar(50),
 cost int,
 type nvarchar(50),
 weight float
 )