

CREATE TABLE inventory (
 ID int IDENTITY(1,1),
 no nvarchar(2) PRIMARY KEY,
 name nvarchar(50),
 cost int,
 type nvarchar(50),
 weight int
 )