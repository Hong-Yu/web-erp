﻿/**
 * Created by hong on 2014/6/4.
 */
function PhaseAdd() {
    // Public member ----------------------------------------------------------
    this.Initialize = Initialize;
    function Initialize() {
       var str_html="";
       str_html += "<tr id='1'>";
       str_html += '<th style=\"text-align:right;\"><input class="inventory_no number_short" type="text" placeholder="" value="" required><\/th>';
       str_html += '<td><input class="inventory_name"  type="text" placeholder="請輸入產品名稱" value=""><\/td>';
       str_html += '<td><input class="inventory_total number_middle" type="number" placeholder="" value=""><\/td>';
        str_html += '<td><input class="inventory_step"  type="number" placeholder="" value=""><\/td>';
        str_html += '<td><input class="inventory_step number_middle"  type="number" placeholder="" value=""><\/td>';
       str_html += "<\/tr>";
       $("tr.inventory_add").before(str_html);
       $("span.inventory_add").bind("click", AddPhase);
       $('span.inventory_minus').bind('click', CancelAddPhase);
       $('tbody.inventory_add').attr('id', 1);
    }
// Private member ---------------------------------------------------------
    function AddPhase() {
        var domain = $("tbody.inventory_add");
        var inventory_max = parseInt(domain.attr("id"));
        domain.attr("id", inventory_max + 1);

        var str_html="";
        str_html += "<tr id='"+(inventory_max+1)+"'>";
        str_html += '<th style=\"text-align:right;\"><input class="inventory_no number_short" type="text" placeholder="" value="" required><\/th>';
        str_html += '<td><input class="inventory_name"  type="text" placeholder="請輸入產品名稱" value=""><\/td>';
        str_html += '<td><input class="inventory_total number_middle" type="number" placeholder="" value=""><\/td>';
        str_html += '<td><input class="inventory_step"  type="number" placeholder="" value=""><\/td>';
        str_html += '<td><input class="inventory_step number_middle"  type="number" placeholder="" value=""><\/td>';
        str_html += "<\/tr>";
        $("tr.inventory_add").before(str_html);

    }
   function CancelAddPhase(){
      var domain = $("tbody.inventory_add");
      var inventory_max = parseInt(domain.attr("id"));
      if(inventory_max>1){
         $('tr[id='+inventory_max+']').remove();
         domain.attr("id", inventory_max - 1);
      }
      else{
         console.log('stop minus inventory');
      }
   }
}