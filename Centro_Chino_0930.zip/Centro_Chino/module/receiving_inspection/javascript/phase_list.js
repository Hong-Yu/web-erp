/**
 * Created by CCT on 2014/5/14.
 */
function PhaseList() {
   // Public member ----------------------------------------------------------
   this.Listing = Listing;
   function Listing() {
      Requesting();
   }
   this.Reload = Reload;
   function Reload() {
      $("tbody.inventory_list").empty();
      Requesting();
   }
   // Private member ---------------------------------------------------------
   function Requesting() {
      var post_data = new Object;
      post_data.requesting = "please give me the inventory list";
      $.post( "http://192.168.1.2:8888/inventory?type=list", post_data )
         .done(function( data ) {
            if(data.successful)
               Success(data.inventory);
            else
               Error();
         });
      function Error() {
         console.log("inventory list error");
//         domain.find("div.authenticated_error").show();
      }
      function Success(inventory) {
         console.log("inventory list success " + JSON.stringify(inventory));
         var current_data;
         for (var row = 0; row < inventory.length; ++row) {
             current_data = inventory[row];
//            AppendInfo(row + 1, current_data);
         }
          // Phase add function
          var str_html= '<tr class="inventory_add"><th colspan="6"><span class="glyphicon glyphicon-plus inventory_add"></span>' + '  '+
             '<span class="glyphicon glyphicon-minus inventory_minus"></span><button class="btn btn-success btn-sm upload">新增至資料庫</button></th></tr>';
          $("tbody.inventory_add").append(str_html);
          var inventory_add = new PhaseAdd();
          inventory_add.Initialize();
         var inventory_new = new PhaseUpload();
         inventory_new.Initialize();

      }
   }
   function AppendInfo(index, input_data) {
      var th =$('th.operation');
         th[0].innerHTML="修改 / 刪除";
      var domain = $("tbody.inventory_list");
       domain.attr("inventory_max", index);
      var str_html="";
      str_html += "<tr>";
      str_html += "<th style=\"text-align:right;\">" + index + "<\/th>";
       str_html += '<td class="inventory_no">' + input_data.inventory_no +'<\/td>';
       str_html += '<td class="inventory_name">' + input_data.inventory_name + '<\/td>';
       str_html += '<td class="inventory_total">' + input_data.inventory_total + '<\/td>';
       str_html += '<td class="inventory_step">' + input_data.inventory_step + '<\/td>';
      str_html += "<td style='text-align:center;'>";
       str_html += '<span class=\"btn btn-warning\" onclick="PhaseRemove.Revise(this);" title="'+ input_data.inventory_no +'"><span class="glyphicon glyphicon-pencil" title="修改時相"></span><\/span>';
      str_html += " ";
      str_html += '<span class=\"btn btn-danger\" onclick="PhaseRemove.Delete(this);" title="'+ input_data.inventory_no +'"><span class="glyphicon glyphicon-trash" title="刪除時相"></span><\/span>';
      str_html += "<\/td>";
      str_html += "<\/tr>";
      domain.append(str_html);
   }
}
