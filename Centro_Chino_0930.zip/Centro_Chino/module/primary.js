/**
 * Created by hong on 2014/9/29.
 */

var sub_page_receiving_inspection = function() {
    var domain_main;
    domain_main = $('div.main-content').empty().css('background-color','transparent');
    var str_html = "<iframe src='receiving_inspection.html' width='650' height='800' scrolling='no'></iframe>"
    domain_main.append(str_html);
//    $('.bottomInfo').empty();
//    $('ul.nav').empty()
//        .append('<li class="active"><a href="#">首頁</a></li>')
//        .append('<li class="active"><a href="#">即時狀態</a></li>');
};
